<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wow</title>
</head>
<body>
    <h2>Área Retângulo</h2>
    <form action="resultado3.php" method="GET">
        <h3>Base:
            <input type="number" name="base" required/>
        </h3>
        <h3>Altura:
        <input type="number" name="altura" required/>
        </h3>
        <input type="submit" value="Calcular"/>
    </form>
</body>
</html>