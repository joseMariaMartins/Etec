<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Média das Notas</title>
</head>
<body>
    <h1>Média das Notas</h1>
    <form action="resultado2.php" method="POST">
        <h3>Nota 1:
            <input type="text" name="n1"/>
        </h3>
        <h3>Nota 2:
            <input type="text" name="n2"/>
        </h3>
        <h3>Nota 3:
            <input type="text" name="n3"/>
        </h3>
        <input type="submit" value="Calcular"/>
    </form>
</body>
</html>