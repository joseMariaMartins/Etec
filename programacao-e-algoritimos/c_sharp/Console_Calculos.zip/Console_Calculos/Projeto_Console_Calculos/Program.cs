﻿using System;
using static System.Console; //deixa na memoria sempre o console, ai vc n precisa ficar escrevendo console
namespace Projeto_Console_Calculos
{
    class Program
    {
        static void Main(string[] args)
        {
            string vresp;
            int opc = 0;
            ForegroundColor = ConsoleColor.Blue;
            BackgroundColor = ConsoleColor.Cyan;
            do 
            {
                Clear();
                SetCursorPosition(30, 0); WriteLine("*** Menu principal ***");
                SetCursorPosition(0, 1);Write(new string('*', 80)); //vai criar * 80 vezes
                SetCursorPosition(25, 2);WriteLine("[1] Ímpar Par");
                SetCursorPosition(25, 3);WriteLine("[2] Cálculo Específico");
                SetCursorPosition(25, 4);WriteLine("[3] Tabuada");
                SetCursorPosition(25, 5);WriteLine("[4] Fim");
                SetCursorPosition(0, 6);Write(new string('*', 80));
                SetCursorPosition(25, 7);Write("Digite sua opção: ");
                SetCursorPosition(42, 7);opc = int.Parse(ReadLine());
                SetCursorPosition(0, 8); Write(new string('*', 80));
                switch (opc)
                {
                    case 1:
                        Impar_Par();
                        break;
                    default:
                        break;
                    
                }
            } while(opc != 4);
        }
        static void Impar_Par()
        {
            string vresp;
            int n;
            Clear();
            SetCursorPosition(25, 10);
            do
            {
                Clear();
                SetCursorPosition(23,12); Write("Digite um número: ");
                n = int.Parse(ReadLine());
                SetCursorPosition(25, 12);
                if (n % 2 == 0)
                {
                    Write($"{n} é par"); //o $ é pra quando colocar a variavel com {} nao entender como texto
                }
                else
                {
                    Write($"{n} é impar");
                }
                SetCursorPosition(25, 14);
                Write("Deseja continuar? (s/n)");
                vresp = ReadLine();
            } while (vresp.ToLower() == "s");
        }
    }
}
