namespace Loja;

public partial class PagEletrodomestico : ContentPage
{
	public PagEletrodomestico()
	{
		InitializeComponent();
	}
}