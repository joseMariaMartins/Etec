namespace Loja;

public partial class PagLogin : ContentPage
{
	public PagLogin()
	{
		InitializeComponent();
	}

    private void btnEntrar_Clicked(object sender, EventArgs e)
    {

    }
}