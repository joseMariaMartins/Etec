namespace Loja;

public partial class PagInicioLoja : ContentPage
{
	public PagInicioLoja()
	{
		InitializeComponent();
	}
}