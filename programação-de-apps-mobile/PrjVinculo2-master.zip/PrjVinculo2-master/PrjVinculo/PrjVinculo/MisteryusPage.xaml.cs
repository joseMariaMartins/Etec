namespace PrjVinculo;

public partial class MisteryusPage : ContentPage
{
	public MisteryusPage()
	{
		InitializeComponent();
	}
}