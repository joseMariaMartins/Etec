namespace PrjVinculo;

public partial class ProdutoPage : ContentPage
{
	public ProdutoPage()
	{
		InitializeComponent();
	}
}