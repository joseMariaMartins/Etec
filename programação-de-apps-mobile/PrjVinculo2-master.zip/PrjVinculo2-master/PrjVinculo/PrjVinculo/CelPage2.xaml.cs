namespace PrjVinculo;

public partial class CelPage2 : ContentPage
{
	public CelPage2()
	{
		InitializeComponent();
	}
}